from ._version import __version__


__author__ = 'hzeyuan'
__copyright__ = 'Copyright 2021, hzeyuan'
