"""
This module provides clients for apps.
"""


from .squid import SquidClient
from .py_cli import ProxyFetcher